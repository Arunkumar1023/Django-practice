from django.shortcuts import render, redirect
from .models import Destination
from django.contrib import messages
from django.contrib.auth.models import User, auth
# Create your views here.

def index(request):

  # dest1 = Destination()
  # dest1.name = 'Mumbai'
  # dest1.desc = "The City that never Sleeps"
  # dest1.image = 'destination_1.jpg'
  # dest1.offer = True
  # dest1.price = 700
  
  # dest2 = Destination()
  # dest2.name = 'Bengaluru'
  # dest2.desc = "Tech park of India"
  # dest2.image = 'destination_2.jpg'
  # dest2.offer = False
  # dest2.price = 800

  # dest3 = Destination()
  # dest3.name = 'Chennai'
  # dest3.desc = "Gateway to South India"
  # dest3.image = 'destination_3.jpg'
  # dest3.offer = False
  # dest3.price = 850

  # dests =[dest1, dest2, dest3]

  dests = Destination.objects.all()
  return render(request, 'index.html',{'dests': dests})

def Chennai(request):
 if request.user.is_authenticated:
  return render(request,'Chennai.html')


 else:
  messages.info(request, 'Pls Login First')
  return redirect('/')